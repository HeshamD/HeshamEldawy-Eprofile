const experiences = [
    {
        company: 'Company A',
        position: 'Software Engineer',
        startDate: 'January 2018',
        endDate: 'Present',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
    }
];
export default experiences;
