import experiences from './WorkExperiencesConst'
import './workExperienceContentsStyling.css';
import { VerticalTimeline, VerticalTimelineElement } from 'react-vertical-timeline-component';
import 'react-vertical-timeline-component/style.min.css'
import { motion } from 'framer-motion';
function WorkExperienceContents() {
    return (<></>
    )
}

export default WorkExperienceContents