import MainHeader from '../header/MainHeader';
import WorkExperienceContents from './content/WorkExperienceContents';

function WorkExperience() {
    const services = [
        {
            title: "Web Developer",
            icon: '../../../../assets/web.png',
        },
        {
            title: "React Native Developer",
            icon: '../../../../assets/mobile.png',
        },
        {
            title: "Backend Developer",
            icon: '../../../../assets/backend.png',
        },
        {
            title: "Content Creator",
            icon: '../../../../assets/creator.png',
        },
    ];

    return (
        <>
            <MainHeader />
            <WorkExperienceContents />
            <div className='box'>
                {services.map((service, index) => (
                    <WorkExperienceContents key={index} service={service} />
                ))}
            </div>
        </>
    )
}

export default WorkExperience